package Loops;
// trying to do 1 0 1 0 1 0 print
// i=2; y=
public class Forloop2 {
    public static void Calculationtable(int no)
    {
        int i;

        for(i=1; i <= 10; i++)
        {

            System.out.println(no+ "*"+i+ "="+no*i );
        }

    }

    public static void main(String[] args)
    {
        Calculationtable(17);

        Calculationtable(20);

    }

}
