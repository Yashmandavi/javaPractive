package Loops;

public class Forloop4 {
    public static void main(String[] args) {

        // even number

         int i ;
        /* for(i = 2 ; i <= 100; i += 2 ){
            System.out.println("" + i );
        }*/

        // odd number
        for(i = 99 ; i >= 1; i -= 2){
            System.out.println("" + i);
        }
    }
}
