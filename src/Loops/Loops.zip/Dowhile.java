package Loops;

public class Dowhile {

    public static void main(String[] args)
    {
        int a = 0;
        do

        {
            System.out.println("my name is khan");

             a++;
        }

        while(a < 8);

    }


}

