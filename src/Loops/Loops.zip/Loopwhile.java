package Loops;

public class Loopwhile {


    public static void main(String[] args) {
        int i = 0;
        while(i < 5){
            System.out.println("my name is yashkumar "+i);
            i++;
        }
    }
}
