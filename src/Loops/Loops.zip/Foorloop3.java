package Loops;

public class Foorloop3 {
    public static void main(String[] args) {

        int x ;

        for( x=0 ; x<=50 ; x++ )
        {
            System.out.println( x );
        }
    }
}
