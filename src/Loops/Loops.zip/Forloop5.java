package Loops;

public class Forloop5 {
    public static void main(String[] args) {
        int x;
        for(x = 0 ; x <= 100; x++){
            if(x % 2 == 0 ){
                System.out.println("the even number " + x);
            }
        }
    }
}
