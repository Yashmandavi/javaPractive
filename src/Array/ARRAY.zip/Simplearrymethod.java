package Array;

public class Simplearrymethod {
    public static void main(String[] args) {
        int[] age = {12, 4, 5, 2, 5};
        System.out.println("The Elements of Arrays:");
        System.out.println("First Element: " + age[0]);
        System.out.println("Second Element: " + age[1]);
        System.out.println("Third Element: " + age[2]);
        System.out.println("Fourth Element: " + age[3]);
        System.out.println("Fifth Element: " + age[4]);
    }
}
