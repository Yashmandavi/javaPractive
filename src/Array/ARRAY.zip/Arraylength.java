package Array;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

public class Arraylength {
    public static void main(String[] args) {


        String[] myArray = {"a", "b", "c","d","e"};

        int ArrayLength = myArray.length; //array length attribute
        System.out.println("The length of the array is: " +ArrayLength);

        // direct
        System.out.println("The lengh of the array is: "+myArray.length);
    }
}



