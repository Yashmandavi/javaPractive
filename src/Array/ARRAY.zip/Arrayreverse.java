package Array;

public class Arrayreverse {
    public static void main(String[] args) {
        char a[] = {'y', 'a', 's', 'h'};
        System.out.println(a);
 for(int i = a.length-1;i>= 0 ; i--)
 {
    // System.out.println(a[i]);
     System.out.print(a[i]);
 }
    }
}
