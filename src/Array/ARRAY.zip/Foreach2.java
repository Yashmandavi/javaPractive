package Array;

public class Foreach2 {
    public static void main(String[] args) {
        int number[] = new int[10];
        int a[] = {22, 23, 432, 421};
        number[0] = 1;
        number[1] = 2;
        number[2] = 3;
        number[3] = 4;
        number[4] = 5;
        number[5] = 6;
        number[6] = 7;
        number[7] = 8;
        number[8] = 9;
        number[9] = 10;
        for (int j = 0; j <= a.length; j++) {

            System.out.println(a[j]);
        }


         /*   for (int i = 0; i <= number.length; i++) {
                System.out.println(number[i]);
            }*/

        }

}
